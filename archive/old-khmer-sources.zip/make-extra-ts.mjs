// ប្រើ: node make-extra-ts.mjs <khmer.extra35000.mjs> <localization-dir>
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
const [src, loc] = process.argv.slice(2);
if (!src || !loc) { console.error("usage: node make-extra-ts.mjs <extra35000.mjs> <localization-dir>"); process.exit(2); }
const dir = path.join(loc, "src", "khmer");
const dataTs = fs.readFileSync(path.join(dir, "data.ts"), "utf8");
const a = dataTs.indexOf("= [["), b = dataTs.lastIndexOf("]];");
if (a < 0 || b < 0) { console.error("cannot parse data.ts"); process.exit(1); }
const existing = JSON.parse(dataTs.slice(a + 2, b + 2));
// ដូច norm() ក្នុង src/khmer/search.ts
const norm = (s) => s.normalize("NFC").trim().toLowerCase().replace(/[?។!！？,，.៖;；:]+$/u, "").replace(/\s+/gu, " ");
const seen = new Set();
for (const [k] of existing) for (const t of k.split("|")) { const n = norm(t); if (n) seen.add(n); }
const M = await import(pathToFileURL(path.resolve(src)).href);
const out = []; let dropT = 0, dropE = 0;
for (const [k, ans] of M.EXTRA_ENTRIES_35000) {
  const keep = [];
  for (const t of k.split("|")) {
    const n = norm(t);
    if (!n || seen.has(n)) { dropT++; continue; }
    seen.add(n); keep.push(t.trim());
  }
  if (keep.length) out.push([keep.join("|"), ans]); else dropE++;
}
const CH = 5000, parts = [];
for (let i = 0, p = 1; i < out.length; i += CH, p++) {
  const name = `data.extra.part${p}.ts`;
  const body = out.slice(i, i + CH).map((e) => "  " + JSON.stringify(e)).join(",\n");
  fs.writeFileSync(path.join(dir, name), `// បង្កើតពី khmer.extra35000.mjs — ទិន្នន័យ Q&A ខ្មែរបន្ថែម (ដកស្ទួនជាមួយ data.ts)\nexport const KHMER_EXTRA_PART_${p}: [string, string][] = [\n${body},\n];\n`);
  parts.push(p);
}
const imp = parts.map((p) => `import { KHMER_EXTRA_PART_${p} } from "./data.extra.part${p}.js";`).join("\n");
const spr = parts.map((p) => `  ...KHMER_EXTRA_PART_${p},`).join("\n");
fs.writeFileSync(path.join(dir, "data.extra.ts"), `${imp}\n\n// ចំណាំ: search.ts ដាក់ទិន្នន័យនេះបន្ទាប់ពី KHMER_ENTRIES (entries ចាស់មានអាទិភាព)\nexport const KHMER_EXTRA_ENTRIES: [string, string][] = [\n${spr}\n];\n`);
console.log({ existingEntries: existing.length, extraEntries: out.length, droppedTriggers: dropT, droppedEntries: dropE, files: parts.length + 1 });

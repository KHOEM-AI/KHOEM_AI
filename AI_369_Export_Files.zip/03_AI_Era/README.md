# 🤖 AI Era & AI 369 (សម័យកាល AI)
- **John McCarthy (JMC)**: 💡 Coined the term 'Artificial Intelligence' in 1956.
- **AI 369 System**: Intelligent system monitoring resources.

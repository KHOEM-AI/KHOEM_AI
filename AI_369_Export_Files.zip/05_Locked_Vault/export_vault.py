import os
import shutil

source_dir = "/data/data/com.termux/files/home/AI_369_Vault"
output_filename = "/data/data/com.termux/files/home/AI_369_Export_Files"

if os.path.exists(source_dir):
    shutil.make_archive(output_filename, 'zip', source_dir)
    print("ឯកសារត្រូវបានខ្ចប់ដោយជោគជ័យ!")
    print(f"ទីតាំងឯកសារ: {output_filename}.zip")
else:
    print("រកមិនឃើញថតឯកសារទេ!")

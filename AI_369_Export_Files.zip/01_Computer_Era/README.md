# 💻 Computer Era (សម័យកាលកុំព្យូទ័រ)
- **Charles Babbage**: ⚙️ Father of computing
- **Alan Turing**: 🧠 Father of modern computer science & AI
